
  <div class="footer">
    <div class="left_footer"> 
      <img src="images/logo4.png" alt="" width="170" height="60"/>
    </div>
    <div class="center_footer"> 
       All Rights Reserved 2016<br/>
       <img src="images/payment.gif" alt="" />
    </div>
    <div class="right_footer"> 
       <a href="home.php">home</a>
       <a href="allproducts.php">All Products</a> 
       <a href="cart.php">Cart</a> 
       <a href="services.php">Services</a> 
       <a href="contact.php">Contact us</a> 
    </div>
  </div>
